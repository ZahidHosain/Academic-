<?php
require_once 'db.php';

?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.f1{
			color: green;
		}
	</style>
	<title></title>
	<center><h1 class="f1">Thank You For Your Shopping</h1></center>
	<div align="right"><a href="home.php">Homepage</a> | <a href="checkout.php">Back</a> | <a href="logout.php">Logout</a></div>
	
</head>
<body>
<form action="checkout.php" method="post">
	<div align="center"><h3>Your Order Details</h3></div>
	<table align="center">
<?php
          session_start();
          
$uid="";
$uid=$_SESSION['uid'];
$sql="select * from `order_t` where order_id='$_SESSION[o_id]'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);

	?>
	<tr>
			<td>Your Order Id:</td>
			<td><?php echo $_SESSION['o_id']; ?></td>
		</tr>

		
		<tr>
			<td>Payment Method:</td>
			<td><?php echo $row['payment']; ?></td>
		</tr>
		<tr>
			<td>Date:</td>
			<td><?php echo $row['date']; ?></td>
		</tr>
		<?php
// unset($_SESSION[''])
?>

	</table>

</form>
</body>
</html>