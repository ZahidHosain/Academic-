<?php
require_once("db.php");
$er=$er1="";
$umail=$upass="";
  if (isset($_POST['login']))
  {
    session_start();
    if (empty($_POST['email'])) {
     $er= "Enter your email";
    }
    else
    {
       $umail = $_POST['email'];
    }
     if (empty($_POST['pwd'])) {
      $er1="Enter your password";
     }
     else
     {
       $upass = $_POST['pwd'];
     }
     

      $sql = $con->query("SELECT * FROM login WHERE email ='$umail'");
      $result = mysqli_fetch_array($sql, MYSQLI_ASSOC);

      if(!empty($result))
      {
        $_SESSION['uid']=$result['id'];
        $_SESSION['uname']=$result['firstname'];
        $_SESSION['email'] = $result['email'];
        $_SESSION['type'] = $result['type'];
        if ($result['type'] == 'admin' && password_verify($upass, $result['password'])){
          header('location: showprofile.php');
        }else if($result['type'] == 'user' && password_verify($upass, $result['password'])){
          header('location: userdashboard.php');
        }else {
          header('location: Login.php');
        }
      }
      else {
        echo "no dat found!!";
      }
  }
?>

<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
	

		 .form-control {
                border: 15px solid teal;
                padding: 15px;
            }
              .form-control tr td {
                padding-bottom: 10px;
            }
	</style>
<title>Login Page</title>
</head>
<body>
<form method="post" action="login.php">
<table width="30%" height="300" bgcolor="white" align="center" class="form-control">

<tr>
<td colspan=2><center><font size=4><b>Login Page</b>
    </center></td>
</tr>

<tr>
<td>Email</td>
<td><input type="email" size=25 name="email" placeholder="Enter email" value="<?php echo $umail; ?>"></td>
<td><span style="color: red"><?php echo $er; ?> </span></td>
</tr>

<tr>
<td>Password</td>
<td><input type="Password" size=25 name="pwd" placeholder="Enter password"></td>
<td><span style="color: red"><?php echo $er1; ?> </span></td>
</tr>
<tr align="center"><td colspan="2">
<a> <input type="submit" name="login" value="Login"></a>
</td></tr>
<tr align="center">
	<td colspan="2"><p>Not a member yet?<a href="Registration.php">Register Here</a></p></td>
</tr>
</table>
</form>
</body>
</html>