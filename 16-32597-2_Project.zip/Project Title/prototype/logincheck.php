<?php
require_once("db.php");

$er=$er1="";
$umail=$upass="";
  if (isset($_POST['login']))
  {
    if (empty($_POST['email'])) {
      $er="Enter your mail";
    }
    else
    {
       $umail = $_POST['email'];
    }
     if (empty($_POST['pwd'])) {
      $er1="Enter your password";
     }
     else
     {
       $upass = $_POST['pwd'];
     }
     

      $sql = $con->query("SELECT * FROM login WHERE email ='$umail'");
      $result = mysqli_fetch_array($sql, MYSQLI_ASSOC);

      if(!empty($result))
      {
        session_start();
        $_SESSION['email'] = $result['email'];
        $_SESSION['type'] = $result['type'];
        if ($result['type'] == 'admin' && password_verify($upass, $result['password'])){
          header('location: showprofile.php');
        }else if($result['type'] == 'user' && password_verify($upass, $result['password'])){
          header('location: userdashboard.php');
        }else {
          header('location: Login.php');
        }
      }
      else {
        echo "no dat found!!";
      }
  }
?>