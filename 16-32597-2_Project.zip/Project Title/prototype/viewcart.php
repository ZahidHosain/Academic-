<?php
require_once("db.php");
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
			.second-half th {
			width: 3%;
			text-align: left;
		}
	</style>
	</head>
	<body>
		<center>
			
		<table>
	   <tr>
               <center><td colspan="3"><h1 align="center">Cart</h1></td></center> 
            </tr>
	    <tr class="second-half">
	      <th>Product Name</th>
	      <th>Quantity</th>
	      <th>Price</th>
	      <th>Total Price</th>
	      <th>Action</th>
	    </tr>
	   <?php
	   $did = (isset($_GET['did']) && !empty($_GET['did'])) ? $_GET['did'] : -1;
	   if ($did != -1) {
	   $sql="delete from cart where cart_id=$did";
	   if (mysqli_query($con,$sql)) {
	   	header("location:viewcart.php");
	   }
	   else
	   {
	   	echo "No data found";
	   }
	   }
	   $sql="SELECT * from cart LEFT JOIN product on product.id=cart.product_id where visible='true' ORDER by cart.cart_id DESC ";
      $result=mysqli_query($con,$sql);
     $count=mysqli_num_rows($result);
     if ($count>0) {
     	$total=0;
	while ($row=mysqli_fetch_assoc($result)) {
		
		?>
		<tr>
			<td><?php echo $row['product_name']; ?> </td>
			<td><?php echo $row['product_quantity']; ?> </td>
			<td>$<?php echo $row['price']?> </td>
			<td>$<?php echo $row['product_quantity'] * $row['price']; ?></td>
			<td><a  href="viewcart.php? did=<?php echo $row['cart_id'] ?>">Remove</a></td>
			<input type="hidden" name="catid" value="<?php echo $row['catid'] ?>">
			
		</tr>
		<?php



		
		$total +=($row['product_quantity'] * $row['price']); }
		?>
		<tr>
			<td colspan="3">Total</td>
			<td>$<?php echo $total; ?></td>
		</tr>
	 <?php 
	
	 } 
       
	 ?>

	    <tr>
	    	<td>
	<a href="checkout.php"><input type="submit" name="check" value="Proceed To Checkout"></a>
	<a href="home.php"><input type="submit" name="continue" value="Continue Shopping"></a>
	<a href="logout.php"><input type="submit" name="logout" value="Logout"></a>
	    </tr>
	</td>
	</table>
</center>
</body>
</html>