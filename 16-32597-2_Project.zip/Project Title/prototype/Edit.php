<!DOCTYPE html>
<html>
<head>
	<title>Edit Product</title>
</head>
<body>
<center>
<h1>Edit Product</h1> 

	<a href="productlist.php">Back</a> |
	<a href="Login.php">logout</a> 
	<br>
	<br>

<form method="post" action="Edit.php">
	<table border="0" width="450px" >
		<tr>
			<td width="40%">Product Name</td>
			<td width="2%">:</td>
			<td><input type="text"  name="product_name1" /></td>
		</tr>
		<tr>
			<td>Price</td>
			<td>:</td>
			<td><input type="text"  name="product_price1" /></td>
		</tr>
		<tr>
			<td>Product Available</td>
			<td>:</td>
			<td><input type="text"  name="product_avlble1" /></td>
		</tr>
		<tr>
			<td>Product Sell Price</td>
			<td>:</td>
			<td><input type="text"  name="product_sell_price1" /></td>
		</tr>
		<tr>
			<td>Product Original Price</td>
			<td>:</td>
			<td><input type="text"  name="product_original_price1" /></td>
		</tr>
		<tr>
			<td>Category Id</td>
			<td>:</td>
			<td><input type="text"  name="category_id1" /></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td><input type="submit"  name="update" value="Update" /></td>
		</tr>
	</table>
</form>
</center>
</body>
</html>