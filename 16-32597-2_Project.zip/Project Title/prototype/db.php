 <?php

   $server="localhost";
   $uname="root";
   $pass="";
   $db="ecommerce";
   
   $con =mysqli_connect($server,$uname,$pass,$db);
   if ($con->connect_error===true) {
   	die("Error in connection");
   }
 /*  else
   {
   	echo "success";
   } */
   ?>