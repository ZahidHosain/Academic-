<?php 
require_once 'db.php';
$er=$payment="";
session_start();
if (isset($_POST['confirm'])) {
	if (empty($_POST['pay'])) {
		$er="select one item";
	}
	else
	{
		$payment=$_POST['pay'];
		$cart_data="select * from cart where uid='$_SESSION[uid]' and visible='true'";
		$result=mysqli_query($con,$cart_data);
		if (mysqli_num_rows($result) > 0) {
			while ($row=mysqli_fetch_assoc($result)) {
			$sql="insert into `order_t`(date,payment,uid,pr_id) values(sysdate(),'$payment','$_SESSION[uid]','$row[product_id]')";
				if(mysqli_query($con,$sql))
		        {
			         $last_id = mysqli_insert_id($con);
			         $_SESSION['o_id']=$last_id;
			         $cart_up="update cart set visible='false' where product_id='$row[product_id]'";
			         mysqli_query($con,$cart_up);
				     header("location:oder.php");
		        }
			}
		}
		
		 
	 }
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.second-half th
			width: 10%;
			text-align: left;
	</style>
</head>
<body>
	<center>
	<table>
		<tr>
			<td>
				<h2>Checkout</h2>
			</td>
		</tr>
				<tbody >
           <form action="checkout.php" method="post">
					<tr class="second-half">
						<td>Payment Method:</td>
						<td><input type="radio" name="pay" value="Cash On Delivery">Cash on Delivery</td>
						</tr>
						<tr>
							<td></td>
						<td><input type="radio" name="pay" value="bKash">bKash</td> </tr> <tr>
                        <td></td>
						<td><input type="radio" name="pay" value="Credit Card">Credit Card</td></tr>
					    <td><span style="color: green"><?php echo $er; ?></span></td>

					</tr> <br>
					<tr></tr> 
					<tr></tr>
					<tr></tr>
					<tr class="second-half">
						<td><button><a href="home.php">Continue Shopping</a></td></button>
						<td><button name="confirm"> Confirm </a></button>
                 
						</td>
					</tr>
					<tr>
						<td><button><a href="logout.php">Logout</a></button></td>
						<td><button><a href="viewcart.php">Back</a></button></td>
					</tr>
				</tbody>
			</table>
			</form>
      </center>
</body>
</html>