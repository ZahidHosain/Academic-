<?php
require_once("db.php");
    session_start();
    $key    = $_POST['key'];
    $sql = "select * from product where name like '".$key."%'";
    $catid = isset($_GET['catid']) ? $_GET['catid'] : -1;

    if($catid == -1)
    {
        $result = mysqli_query($con, $sql);

        if (mysqli_num_rows($result) > 0) {
        $lists = '';
        while ($row = mysqli_fetch_assoc($result)) {
                $image_data = $row['pic'];
                $encoded_image = base64_encode($image_data);

                $lists .= "<form method=\"post\" action=\"cart.php\" class=\"form-horizontal\" role=\"form\">
                <div class=\"col-12 col-md-6 col-lg-4\">
                        <img class=\"card-img-top\" src = 'data:image/JPG;base64, {$encoded_image}' alt=\"Card image cap\" style=\"max-height: 250px; max-width: 200px; \"></img>
                            <div class=\"card-body\">
                                <h4 class=\"card-title\"><a href=\"product.html\" title=\"View Product\">$row[name]</a></h4>
                                <p class=\"card-text\">$row[description]</p>
                                <div class=\"row\">
                                    <div class=\"col\">
                                        <p class=\"btn btn-danger btn-block\">$row[price] $</p>
                                </div> <br>
                                <div>
                                  <input type=\"number\" name=\"quantity\" min=\"1\"> </input> <br>
                                 </div> 
                                    <div class=\"col\">
                                        <button class=\"btn btn-success btn-block\" name=\"cart\">Add to cart</button>
                                    </div>
                            </div>
                            <input type=\"hidden\" name=\"productid\" value=\"$row[id]\">
                            <input type=\"hidden\" name=\"productname\" value=\"$row[name]\">
                            
                            </form>
                </div>

            </div>
                ";
            }

            echo $lists;


        }

    }else 
    {
        $result = mysqli_query($con, "select * from product where catid='$catid'");

        if (mysqli_num_rows($result) > 0) {
            $lists = '';
        while ($row = mysqli_fetch_assoc($result)) {
                $image_data = $row['pic'];
                $encoded_image = base64_encode($image_data);

                $lists .= "<div class=\"col-12 col-md-6 col-lg-4\">
                        <img class=\"card-img-top\" src = 'data:image/JPG;base64, {$encoded_image}' alt=\"Card image cap\" style=\"max-height: 250px; max-width: 200px; \"></img>
                            <div class=\"card-body\">
                                <h4 class=\"card-title\"><a href=\"product.html\" title=\"View Product\">$row[name]</a></h4>
                                <p class=\"card-text\">$row[description]</p>
                                <div class=\"row\">
                                    <div class=\"col\">
                                        <p class=\"btn btn-danger btn-block\">$row[price] $</p>
                                    </div>
                                    <div class=\"col\">
                                        <a href=\"cart.php\" class=\"btn btn-success btn-block\">Add to cart</a>
                                    </div>
                                </div>
                            </div>
                            </div>
                ";
            }

            echo "$lists";
        }
    }
?>