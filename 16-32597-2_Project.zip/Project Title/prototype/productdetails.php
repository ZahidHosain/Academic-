<?php
require_once("db.php");
$sql="select * from product where catid='$_GET[catid]'";
$result=mysqli_query($con,$sql);
$count=mysqli_num_rows($result);
if ($count>0) {
	while ($row=mysqli_fetch_assoc($result)) {
			$image_data = $row['pic'];
			$encoded_image = base64_encode($image_data); 
			echo "<img src = 'data:image/JPG;base64, {$encoded_image}' class='image' style=\"max-width: 150px;max-height: 200px;\"></img>";
		?>
	    <h3>$<?php echo $row['price']; ?></h3>
	    <h4><?php echo $row['description']; ?></h4>
	    <?php echo $row['quan']; ?>
	    <?php
	
         }
         }
	
else
{
	echo "there is no product";
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>All Products</title>
</head>
<body>
	<form>
		<table>
			<tr>
				<td>

					
				</td>
			</tr>
		</table>
	</form>
</body>
</html>