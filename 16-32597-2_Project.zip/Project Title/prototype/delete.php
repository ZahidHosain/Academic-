<?php
require_once("db.php");
if (isset($_POST['submit'])) {
	$id=$_POST['pid'];
	$sql="delete from product where id=$id";
    mysqli_query($con,$sql);
  echo " <script> alert('your item is deleted'); </script>";
   ?>
  
   <?php
}
else
{
	
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Delete Product</title>
</head>
<body>
<center>
<h1>Delete Product</h1> 

	<a href="showprofile.php">Back</a> |
	<a href="Login.php">logout</a> 
	<br>
	<br>
	<form action="delete.php" method="post" onsubmit="return validation()">
	
	<center>	<div>
			ProductId <input type="text" name="pid" id="pid">
		</div>


	<!-- <table border="0" width="450px" >
		<tr>
			<td width="40%">Product Name</td>
			<td width="2%">:</td>
			<td><input type="text" name="name"> </td>
		</tr>
		<tr>
			<td>Price</td>
			<td>:</td>
			<td><input type="text" name="price"></td>
		</tr>
		<tr>
			<td>Product Available</td>
			<td>:</td>
			<td><input type="text" name="available"></td>
		</tr>
		<tr>
			<td>Product Sell Price</td>
			<td>:</td>
			<td><input type="text" name="sellprice"></td>
		</tr>
		<tr>
			<td>Product Original Price</td>
			<td>:</td>
			<td><input type="text" name="orprice"></td>
		</tr>
		<tr>
			<td>Category Id</td>
			<td>:</td>
			<td><input type="text" name="catid"></td>
		</tr>
	</table> -->
<br>
<b>Are you sure? this can't be undone if you click confirm!</b>
		<br>
		<input type="submit" name="submit" value="Confirm">
</form>
</center>
<div id="valid" style="color:green;"></div>
<script type="text/javascript">
	function validation() {
			var id = document.getElementById('pid').value;
	if (id == '') {
		document.getElementById("valid").innerHTML="Enter your product id for delete any product";
		return false;
	}
	else
	{
		return true;
	}
	}


</script>
</body>
</html>