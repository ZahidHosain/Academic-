<?php
require_once("db.php");

session_start();
if(empty($_SESSION))
{
	header('location: login.php');
}
$email=$_SESSION['email'];
$sql="select * from login where email='$email'";
$result = mysqli_query($con,$sql);
while($row=mysqli_fetch_assoc($result))
{
	$email=$row['email'];
	$type=$row['type'];
	$password=$row['password'];
	$firstname=$row['firstname'];
	$lastname=$row['lastname'];
//	$con->close();
}

 ?>

 <!DOCTYPE html>
<html>
<head>
	<title>User dashboard</title>
	<style type="text/css">
		.first-half {
			/*float: left;*/
		}

		.second-half {
			/*float: right;*/
		}

		.second-half th {
			width: 10%;
			text-align: left;
		}
	</style>
</head>
<body>
	<form action="userdashboard.php" method="post">
	<center><h1>Dashboard | <?php echo $_SESSION['type']; ?></h1></center>
	<center><h1>Welcome to <?php echo $firstname; ?> <?php echo $lastname; ?></h1></center>
<center>	
<table border="0" width="100%" >
		<tr class="first-half">
			<td>First Name</td>
			<td><?php echo $firstname; ?></td>
		</tr>
			<tr class="first-half">
			<td>Last Name</td>
			<td><?php echo $lastname; ?></td>
		</tr>
			<tr class="first-half">
			<td>Email</td>
			<td><?php echo $email; ?></td>
		</tr>
	<!-- 	<tr class="first-half">
			<td>Password</td>
			<td><?php echo $password; ?></td>
		</tr> -->
		<tr class="first-half">
			<td>Type</td>
			<td><?php  echo $type; ?></td>
		</tr >
	

		<tr>
			<td>
				<a href="home.php">Show HomePage</a>
			</td>
		</tr>
		<tr class="second-half">
		 	  <th>OrderNo</th>
		 	  <th>UserId</th>
		      <th>Date</th>
		      <th>Product Name</th>
		      <th>Quantity</th>
		     <!--  <th>Product price</th>
		      <th>Total price</th>
		      <th>Status</th> -->
	    </tr>
	    	<?php
	    	$uid="";
     $uid= $_SESSION['uid']; 
	$sql="SELECT order_id,order_t.date,payment,product_name,product_quantity
	from order_t,cart where cart.product_id=order_t.pr_id";
     $result=mysqli_query($con,$sql);
     if (mysqli_num_rows($result) > 0) {
	while($row=mysqli_fetch_assoc($result))
	{
		?>
		 <tr class="second-half">
	      <td><?php echo $row['order_id']; ?></td>
	      <td><?php echo $uid; ?></td>
	      <td><?php echo $row['date'];?></td>
	      <td><?php echo $row['product_name']; ?></td>
	      <td><?php echo $row['product_quantity']; ?></td>
	     <!--  <td><?php echo $row['price']; ?></td>
	      <td><?php echo $row['price'] * $row['product_quantity']; ?></td> -->
	      <td><?php echo $row['payment']; ?></td>
	    </tr>
		<?php
	}
       }
	?> 
		
	    <tr class="second-half">
	      <td colspan="2"><h2>Total Amount:<h2></td>
	      <td>180000</td>
	    </tr> 


	    <tr>
	    	<td><a href="logout.php">LOgout</a></td>
	    </tr>
	</table>
	</center>
	</form>
</body>
</html>