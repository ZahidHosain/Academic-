<?php 
require_once 'db.php';
session_start();
if (isset($_POST['cart'])&& !empty($_SESSION['uid'])) {
	
	$pro_id=$_POST['productid'];
	$name=$_POST['productname'];
	$quantity=$_POST['quantity'];
	if ($quantity>0) {
		$sql="insert into cart(product_id,product_name,product_quantity,uid,visible) values('$pro_id','$name','$quantity','$_SESSION[uid]','true')";
	mysqli_query($con,$sql);
	header("location:viewcart.php");
	}
	else
	{
		header("location:home.php");
	}
}
   else
   {
   	header("location:home.php");
   }

?>

