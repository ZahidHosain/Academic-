<?php
require_once("db.php");

$er=$er1=$er2=$er3=$er4=$er5="";
$firstname=$lastname=$email=$password=$conpass=$type="";
if (isset($_POST['submit'])) {
    session_start();
    $_SESSION['msg']="";
    if (empty($_POST['fname'])) {
       $er="Enter your first name";
    }
    else
    {
        $firstname=test($_POST['fname']);
    }
    if (empty($_POST['lname'])) {
        $er1="Enter your last name";
    }
    else
    {
         $lastname=test($_POST['lname']);
    }
    if (empty($_POST['email'])) {
       $er2="Enter your mail address";
    }
    else
    {
        $email=test($_POST['email']);
    }
    if (empty($_POST['password'])) {
        $er3="Enter your password";
    }
    else
    {
      $password=test($_POST['password']);   
    }
    if (empty($_POST['password1'])) {
        $er4="Enter your confirm password";
    }
    else
    {
         $conpass=test($_POST['password1']);
    }
     if (empty($_POST['type'])) {
         $er5="Enter your type";
     }
     else
     {
         $type=test($_POST['type']);

     
    if ($password==$conpass && !empty($firstname) && !empty($lastname) && !empty($email) && !empty($password) && !empty($conpass) && !empty($type)) {
        $pw = password_hash($password, PASSWORD_BCRYPT);
        $password = $conpass = $pw;

        echo $pw;

        $_SESSION['pppp'] = $pw;

        $sql="insert into login (firstname,lastname,email,password,confirmpass,type) values (' $firstname','$lastname','$email','$password','$conpass','$type')";
        mysqli_query($con,$sql);
        $type=$_SESSION['type'];
        
        header("location: Login.php");
        } else{
           // $_SESSION['msg']="dede";
           echo"The two passwords do not match";
        }
    }
}
function test($data)
{
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
} 
?>
<!DOCTYPE html>
<html>
    <head>
       <style type="text/css">
            .header {
                text-align: center;
            }
            .form-control {
                border: 15px solid teal;
                padding: 15px;
            }

            .form-control tr td {
                padding-bottom: 10px;
            }
        </style> 
    </head>
    <body bgcolor="white" font-color="red">
        <form action="Registration.php" method="post">
        <table border='0' width='480px' cellpadding='0' cellspacing='0' align='center' class="form-control">
            <tr>
                <td class="header" colspan="2"><h1 align="center">Registration Form</h1></td>
            </tr>
            <tr>
                <td>First Name</td>
                <td><input type='text' name='fname' placeholder="First Name" value="<?php echo $firstname;?>"></td>
                <td><span style="color: red"><?php echo $er; ?> </span> </td>
            </tr>
            <tr>
                <td>Last Name</td>
                <td><input type='text' name='lname' placeholder="Last Name" value="<?php echo $lastname; ?>"></td>
                <td><span style="color: red"><?php echo $er1; ?> </span> </td>
            </tr>
            <tr>
                <td>Email address</td>
                <td><input type='text' name='email' placeholder="Enter your email address" value="<?php echo $email; ?>"></td>
                <td><span style="color: red"><?php echo $er2; ?> </span> </td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type='Password' name='password' placeholder="Enter your password" value="<?php echo $password; ?>"></td>
                <td><span style="color: red"><?php echo $er3; ?> </span> </td>
            </tr>
            <tr>
                <td>Confirm Password</td>
                <td><input type='password' name='password1' placeholder="Confirm your password" value="<?php echo $conpass; ?>"></td>
                <td><span style="color: red"><?php echo $er4; ?> </span> </td>
            </tr>
               <tr>
                <td>Type</td>
                <td><input type='text' name='type' placeholder="your type" value="<?php echo $type; ?>"></td>
                <td><span style="color: red"><?php echo $er5; ?> </span> </td>
            </tr>
            <tr>
            	<td colspan="2"><input type="checkbox" name="terms"> I agree with all the terms and conditions.</td>
            </tr>

            <tr>
                <td><input type='submit' name='submit' value="Register"></td>
            </tr>
            <tr>
            	<td><p>Already registered? <a href="Login.php">Login Here</a></p></td>
            </tr>
        </table>
        </form>
    </body>
</html>