<?php
require_once("db.php");

$er="";
$name="";
if (isset($_POST['submit'])) {
	if (empty($_POST['cname'])) {
		$er="Type category name";
	}
	else
	{
		 $name=$_POST['cname'];
	}
    $sql="insert categoris set name='$name'";
    mysqli_query($con,$sql);
 
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Category Page</title>
</head>
<body>
<form action="category.php" method="post">
	<div>
		category name <input type="text" name="cname"> <br>
		<span style="color: red"><?php echo $er; ?> </span>
	</div>
	<br>
	<div>
		<input type="submit" name="submit" value="Submit">
	</div>
	
</form>
</body>
</html>