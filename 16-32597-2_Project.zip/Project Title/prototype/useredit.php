<!DOCTYPE html>
<html>
<head>
	<title>Edit Product</title>
</head>
<body>
<center>
<h1>Edit Product</h1> 

	<a href="userdashboard.php">Back</a>
	<a href="logout.php">logout</a> 
	<br>
	<br>

<form method="post" action="Edit.php">
	<table border="0" width="450px" >
		<tr>
			<td width="40%">Id</td>
			<td width="2%">:</td>
			<td><input type="text"  name="id" /></td>
		</tr>
		<tr>
			<td>User Name</td>
			<td>:</td>
			<td><input type="text"  name="uname" /></td>
		</tr>
		<tr>
			<td>Email</td>
			<td>:</td>
			<td><input type="text"  name="email" /></td>
		</tr>
		<tr>
			<td>Password</td>
			<td>:</td>
			<td><input type="Password"  name="upass" /></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td><input type="submit"  name="update" value="Update" /></td>
		</tr>
	</table>
</form>
</center>
</body>
</html>