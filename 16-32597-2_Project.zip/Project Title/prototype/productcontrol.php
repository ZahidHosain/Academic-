<?php
require_once("db.php");

$err=$er1=$er2=$er3=$er4="";
$name=$price=$quan=$des=$cat=$erpic="";
if (isset($_POST['submit'])) {

  if (empty($_POST['pname'])) {
    $err="Enter product name";
  }
  else
  {
    $name=$_POST['pname'];
  }
  
  if (empty($_POST['pprice'])) {
    $er1="Enter product price";
  }
  else
  {
    $price=$_POST['pprice'];
  }
  // if (empty($_POST['quan'])) {
  //   $er2="Enter product quantity";
  // }
  // else
  // {
  //   $quan= $_POST['quan'];
  // }
  if (empty($_POST['des'])) {
    $er3="Enter product description";
  }
  else
  {
    $des=$_POST['des'];
  }
  if ($_POST['catname']=='select') {
    $er4="Select category";
  }
  else
  {
    $cat=$_POST['catname'];
  }

  if(!empty($_FILES['image']['tmp_name']) && !empty($cat))
  {
        $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));

    $sql="insert into product (`name`,`price`,`catid`,`description`,`pic`) values ('$name','$price','$cat','$des','$image')";

    mysqli_query($con, $sql);
    $name=$des="";

    unset($price,$cat,$image); 
    }
    else
      {
        $erpic="File cannot be empty or unsuccess";
      }

} 

?>


<!DOCTYPE html>
<html>
<head>
	<title>Product control</title>
</head>
<body>
	<center>
	<h1>Product Control</h1>
<form action="productcontrol.php" method="post" enctype="multipart/form-data">
	<a href="showprofile.php">Back</a> |
	<a href="Login.php">logout</a> 
	<br>
	<br>
	<div>
		 Name <input type="text" name="pname" placeholder="Enter product name" value="<?php echo $name; ?>">  <br>
     <span style="color: red"><?php echo $err; ?> </span>
	</div>
	   <br>
   <div>Price <input type="number" name="pprice" placeholder="Enter product price" value="<?php echo $price; ?>"> <br>
    <span style="color: red"><?php echo $er1; ?> </span></div>
      <br>
    <!--  <div>Quantity <input type="number" name="quan" placeholder="Enter quantity" value="<?php echo $quan; ?>"><br> 
      <span style="color: red"><?php echo $er2; ?> </span></div> -->
     <br>
      <div>
        Category Name
        <select name="catname">
          <option value="select">Select</option>
          <?php
           $sql="select * from categoris";
           $result=mysqli_query($con,$sql);
           while ($row=mysqli_fetch_assoc($result)) {
           ?>
              <option value="<?php echo $row['id']; ?>" <?php echo !empty($cat) && $cat==$row['id'] ? "selected" : "" ?>><?php echo $row['name']; ?></option>
              <?php
           }
          ?>
        </select> <br>
        <span style="color: red"><?php echo $er4; ?> </span>
      </div>
  <br>
    </div><div>	Descripton <input type="textarea" name="des" placeholder="Enter description" value="<?php echo $des; ?>"> <br>
     <span style="color: red"><?php echo $er3; ?> </span></div>
    <br>
    <div>
   Pic <input type="file" name="image" src="<?php echo $image; ?>">
   <span style="color: red"><?php echo $erpic; ?></span>
    </div>
    	<br>
     <input type="submit" name="submit" value="Submit">

</form>
	
	</center>
</body>
</html>
