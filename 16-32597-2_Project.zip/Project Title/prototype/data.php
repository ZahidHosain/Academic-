<?php
require_once 'db.php';
$sql="SELECT * from product WHERE name LIKE '".$_REQUEST["q"]."%';";

error_reporting(0);
$res=mysqli_query($con,$sql);


$list="";
// for($i=0;$i<mysqli_num_rows($res);$i++)
	
// 	{
// 		//$row[$i]=mysqli_fetch_array($res);
 
    
		$rows = array();
        while($row = mysqli_fetch_array($res))
            $rows[] = $row;
         
     


        foreach($rows as $row )
        {
                 $list .= "<div><a href=\"home.php?productid=$row[id]\"> $row[name]</a></div>";

				// $list.="<br/>".$row["name"]."<br/>".$row["price"];
				// $pro_name=$row["name"];
				// $pro_image=$row["picture_dir"];
				// $pro_sellprice=$row["price"];
				// $pro_id=$row["id"];
				// $pro_type=$row["type"];
				// $pro_brand=$row["brand"];
				// $pro_discount=$row["discount"];
				// $pro_details=$row["details"];




				
			}


				

					
		                  //  <div class='panel panel-info proDuct'>
		                     //   <div class='panel-heading'>$pro_name</div>
		                 
		                        // <div class='panel-heading'>$ .$pro_sellprice.00
		                           
		                        // </div>
		                       //  </div>


    

     //              echo "
		   //                        <div class='col-md-4'>
		   //                  <div class='panel panel-info proDuct'>
		   //                      <div class='panel-heading'>$pro_name</div>
		   //                       <div class='panel-body'>
		   //                           <img src='$pro_image' style='width: 170px; height: 260px;' class='img img-responsive'/>
		   //                        </div>
		   //                       <div class='panel-heading'>$ .$pro_sellprice.00
		   //                           <button pid='$pro_id' style='float:right;' id='product' class ='btn btn-primary btn-xs '>AddToCart</button>
		   //                       </div>
		   //                       </div>
		                         
		   //              </div>        
		               
		                         
		                      
		               

					// ";

					


		// }


		if($list==="")
					{
						echo " Search again with other Keywords";
					}
					else
					{
						echo "$list";
					}

?>
