
<?php

require_once 'db.php';
	session_start();

	if(empty($_SESSION))
	{
		header('location:login.php');
	}

	if(isset($_SESSION['type']) && !empty($_SESSION['type']) && $_SESSION['type']!=null)
	{
		if(strtolower($_SESSION['type'])=='admin')
		{
			// header('location:showprofile.php');
		}else if(strtolower($_SESSION['type'])=='user')
		{
			header('location:userdashboard.php');
		}else {
			header('location:login.php');
		}
	}else {
		header('header: login.php');
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Page</title>
	<style type="text/css">
		.row {
  display: flex;
}

.column {
  flex: 33.33%;
  padding: 5px;
}
	</style>
</head>
<body>
 <center><h1>Admin Page</h1> </center>
 <center>
 	 <a href="home.php">Back</a> |
	<a href="logout.php">logout</a> 
 </center>
<div align="right">
	<a href="productcontrol.php">Add</a> | <a href="">Update</a> | <a href="delete.php">Delete</a>
</div>
	
	<br>
	<br>
        <?php
			$result = mysqli_query($con, "select * from product order by product.id desc");

        if (mysqli_num_rows($result) > 0) {
            $lists = '';
        while ($row = mysqli_fetch_assoc($result)) {
                $image_data = $row['pic'];
                $encoded_image = base64_encode($image_data);

                $lists .= "
                <div class=\"row\">
               <div class=\"column\">
                        <img src = 'data:image/JPG;base64, {$encoded_image}' height=\"200px \"; width=\"250px \"></img>
                            <div>
                            <div class=\"column\">
                                <h4>$row[name]</a></h4>
                                </div>
                                <div  class=\"column\">
                                <p>$row[description]</p>
                                </div>
                                    <div class=\"column\">
                                        <p>$row[price] $</p>
                                    </div>
                      
                            </div>
                ";
            }

            echo "$lists";
        }
    
?>
</body>
</html>