<?php
require_once("db.php");

$sql="select * from categoris";
$result=mysqli_query($con,$sql);
	while ($row=mysqli_fetch_assoc($result)) {
	?>
	<a href="productdetails.php?catid=<?php echo $row['id'];?>"> <?php echo $row['name']; ?></a>
	<?php
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
</head>
<body>
<h1>Category Name</h1>
<hr>
<hr>
<?php

?>
<form action="category_details.php" method="post">
	<table>
	<tr>
		<!--<td><img width="300" height="300" src="img/cloth.jpg" alt=""><br/><center><a href="productdetails.php"><h3><?php  echo $row['name']='ladiscloth';?></h3></a></center></td> 

		<td><img width="300" height="300" src="img/watch.jpg" alt=""><br/><center><a href="productdetails.php"><h3><?php  echo $row['name']='Watch';?></h3></a></center></td>
		<td><img width="300" height="300" src="img/cosmetics.jpg" alt=""><br/><center><a href="productdetails.php"><h3><?php  echo $row['name']='Cosmetics';?></h3></a></center></td>
		<td><img width="300" height="300" src="img/jewelary.jpg" alt=""><br/><center><a href="productdetails.php"><h3><?php  echo $row['name']='Jewellary';?></h3></a></center></td> -->
	</tr> 
</table>
</form>

</body>
</html>